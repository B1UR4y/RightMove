// Логика страницы.
// Начать → отсчёт 10 секунд → включается камера и идёт время тренировки.
// Завершить → камера выключается, открывается отчёт.
// Отчёт и похвала пока демонстрационные, потом их будут строить по данным модели.

const COUNTDOWN_SECONDS = 10;

const $ = (id) => document.getElementById(id);

let stream = null;        // поток с камеры
let countdownTimer = null;
let workoutTimer = null;
let seconds = 0;          // время тренировки

function show(id) { $(id).classList.remove("hidden"); }
function hide(id) { $(id).classList.add("hidden"); }

function formatTime(total) {
  const m = String(Math.floor(total / 60)).padStart(2, "0");
  const s = String(total % 60).padStart(2, "0");
  return `${m}:${s}`;
}

// Смена упражнения меняет подпись на видео
$("exercise").addEventListener("change", () => {
  $("exerciseName").textContent = $("exercise").value;
});

// Начать: обратный отсчёт
$("btnStart").addEventListener("click", () => {
  $("btnStart").disabled = true;
  $("btnReport").disabled = true;
  $("exercise").disabled = true;
  hide("cameraError");

  let left = COUNTDOWN_SECONDS;
  $("countdownNum").textContent = left;
  show("countdown");

  countdownTimer = setInterval(() => {
    left -= 1;
    $("countdownNum").textContent = left;
    if (left <= 0) {
      clearInterval(countdownTimer);
      hide("countdown");
      startWorkout();
    }
  }, 1000);
});

// После отсчёта: включаем камеру и запускаем время
async function startWorkout() {
  $("btnStop").disabled = false;
  await startCamera();

  seconds = 0;
  $("timer").textContent = formatTime(seconds);
  workoutTimer = setInterval(() => {
    seconds += 1;
    $("timer").textContent = formatTime(seconds);
  }, 1000);
}

async function startCamera() {
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
    $("camera").srcObject = stream;
    hide("demo");
    show("camera");
  } catch (err) {
    // Камеры нет или доступ запрещён – оставляем гифку и показываем сообщение
    show("cameraError");
  }
}

function stopCamera() {
  if (stream) {
    stream.getTracks().forEach((track) => track.stop());
    stream = null;
  }
  $("camera").srcObject = null;
  hide("camera");
  show("demo");
}

// Завершить: выключаем камеру и показываем отчёт
$("btnStop").addEventListener("click", () => {
  clearInterval(countdownTimer);
  clearInterval(workoutTimer);
  hide("countdown");
  stopCamera();

  $("btnStop").disabled = true;
  $("btnStart").disabled = false;
  $("btnReport").disabled = false;
  $("exercise").disabled = false;

  openReport();
});

// Отчёт
function openReport() {
  $("reportExercise").textContent = $("exercise").value;
  $("reportTime").textContent = formatTime(seconds);
  show("report");
}

$("btnReport").addEventListener("click", openReport);
$("btnClose").addEventListener("click", () => hide("report"));

// Закрытие отчёта по клику на затемнённый фон
$("report").addEventListener("click", (e) => {
  if (e.target === $("report")) hide("report");
});
